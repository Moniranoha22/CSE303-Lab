numbers=[i for i in range (1,1001) if i%8==0]
print(numbers)