numbers=[i for i in range (1,1001) if '6' in str(i)]
print(numbers)