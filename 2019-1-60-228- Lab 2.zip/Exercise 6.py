string = "Practice Problems to Drill List Comprehension in your Head"
word1 = string.split()
length = {word2 : len(word2) for word2 in word1}
print("The length of each word in a sentence: ")
print(length)
