string = "Patience Problems to Drill List Comprehension in your Head"
vowel = [n for n in string if n!='a' and n!='A'and n!='e' and n!='E'and n!='i' and n!='I'and n!='o' and n!='O'and n!='u' and n!='U']
print(''.join(vowel))