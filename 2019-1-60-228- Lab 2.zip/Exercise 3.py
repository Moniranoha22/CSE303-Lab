string = "Patience Problems to Drill List Comprehension in your Head"
spaces = [n for n in string if n == ' ']
print(len(spaces))